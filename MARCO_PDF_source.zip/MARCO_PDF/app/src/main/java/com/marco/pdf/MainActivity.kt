package com.marco.pdf

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.IOException

class MainActivity : Activity() {
    private val gold = Color.rgb(212, 175, 55)
    private val black = Color.rgb(8, 8, 8)
    private val panel = Color.rgb(25, 25, 25)

    private var descriptor: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var currentPage = 0
    private var zoom = 1.0f
    private lateinit var pageImage: ImageView
    private lateinit var pageLabel: TextView
    private lateinit var openButton: Button
    private lateinit var shareButton: Button
    private var selectedUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(black)
            setPadding(18, 18, 18, 12)
        }

        val title = TextView(this).apply {
            text = "MARCO PDF"
            textSize = 27f
            setTextColor(gold)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
            setPadding(0, 12, 0, 4)
        }
        val subtitle = TextView(this).apply {
            text = "YOUR DOCUMENT READER"
            textSize = 10f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 18)
        }

        openButton = makeButton("＋  افتح ملف PDF")
        openButton.setOnClickListener { choosePdf() }

        pageImage = ImageView(this).apply {
            setBackgroundColor(Color.rgb(35, 35, 35))
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "صفحة ملف PDF"
        }

        val imageHolder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(panel)
            setPadding(8, 8, 8, 8)
        }
        imageHolder.addView(pageImage, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        pageLabel = TextView(this).apply {
            text = "افتح ملف PDF للبدء"
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(8, 12, 8, 12)
        }

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val prev = makeButton("السابق")
        prev.setOnClickListener { showPage(currentPage - 1) }
        val next = makeButton("التالي")
        next.setOnClickListener { showPage(currentPage + 1) }
        nav.addView(prev, LinearLayout.LayoutParams(0, 48, 1f).apply { marginEnd = 6 })
        nav.addView(next, LinearLayout.LayoutParams(0, 48, 1f).apply { marginStart = 6 })

        val zoomRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val zoomOut = makeButton("− تصغير")
        zoomOut.setOnClickListener { changeZoom(0.8f) }
        val zoomIn = makeButton("＋ تكبير")
        zoomIn.setOnClickListener { changeZoom(1.25f) }
        zoomRow.addView(zoomOut, LinearLayout.LayoutParams(0, 44, 1f).apply { marginEnd = 6 })
        zoomRow.addView(zoomIn, LinearLayout.LayoutParams(0, 44, 1f).apply { marginStart = 6 })

        shareButton = makeButton("مشاركة ملف PDF").apply {
            isEnabled = false
            alpha = 0.5f
            setOnClickListener { sharePdf() }
        }

        main.addView(title)
        main.addView(subtitle)
        main.addView(openButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 50
        ))
        main.addView(imageHolder, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { topMargin = 14; bottomMargin = 8 })
        main.addView(pageLabel)
        main.addView(nav)
        main.addView(zoomRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 48
        ).apply { topMargin = 7 })
        main.addView(shareButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 48
        ).apply { topMargin = 7 })

        setContentView(main)
    }

    private fun makeButton(label: String): Button = Button(this).apply {
        text = label
        textSize = 14f
        setTextColor(black)
        setBackgroundColor(gold)
        isAllCaps = false
    }

    private fun choosePdf() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivityForResult(intent, 100)
    }

    @Deprecated("Legacy result callback kept for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                selectedUri = uri
                openPdf(uri)
            }
        }
    }

    private fun openPdf(uri: Uri) {
        try {
            closePdf()
            descriptor = contentResolver.openFileDescriptor(uri, "r")
            val fd = descriptor ?: throw IOException("تعذر فتح الملف")
            renderer = PdfRenderer(fd)
            currentPage = 0
            zoom = 1.0f
            shareButton.isEnabled = true
            shareButton.alpha = 1f
            showPage(0)
            Toast.makeText(this, "تم فتح الملف بنجاح", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            closePdf()
            Toast.makeText(this, "تعذر فتح الملف: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showPage(index: Int) {
        val pdf = renderer ?: return
        if (index !in 0 until pdf.pageCount) return
        try {
            currentPage = index
            pdf.openPage(index).use { page ->
                val scale = minOf(1600f / page.width, 2200f / page.height, 2.5f)
                val bitmap = Bitmap.createBitmap(
                    (page.width * scale).toInt().coerceAtLeast(1),
                    (page.height * scale).toInt().coerceAtLeast(1),
                    Bitmap.Config.ARGB_8888
                )
                bitmap.eraseColor(Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                pageImage.setImageBitmap(bitmap)
                pageImage.scaleX = zoom
                pageImage.scaleY = zoom
            }
            pageLabel.text = "الصفحة ${currentPage + 1} من ${pdf.pageCount}"
        } catch (e: Exception) {
            Toast.makeText(this, "حدث خطأ أثناء عرض الصفحة", Toast.LENGTH_SHORT).show()
        }
    }

    private fun changeZoom(factor: Float) {
        zoom = (zoom * factor).coerceIn(0.6f, 3.0f)
        pageImage.animate().scaleX(zoom).scaleY(zoom).setDuration(120).start()
    }

    private fun sharePdf() {
        val uri = selectedUri ?: return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "مشاركة ملف PDF"))
    }

    private fun closePdf() {
        try { renderer?.close() } catch (_: Exception) {}
        try { descriptor?.close() } catch (_: Exception) {}
        renderer = null
        descriptor = null
    }

    override fun onDestroy() {
        closePdf()
        super.onDestroy()
    }
}
